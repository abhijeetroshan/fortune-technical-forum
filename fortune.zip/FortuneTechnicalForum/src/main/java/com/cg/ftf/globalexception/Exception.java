package com.cg.ftf.globalexception;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class Exception {
	@ ExceptionHandler(NullPointerException.class)
	public void handleException(HttpServletResponse res) {
		try {
			res.sendRedirect("http://localhost:8080/FortuneTechnicalForum/hello/notFound");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
